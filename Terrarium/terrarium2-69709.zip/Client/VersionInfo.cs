//------------------------------------------------------------------------------
//      Copyright (c) Microsoft Corporation.  All rights reserved.                                                           
//------------------------------------------------------------------------------

using System.Reflection;

[assembly : AssemblyConfiguration("")]
[assembly : AssemblyCompany("Microsoft")]
[assembly : AssemblyProduct("Terrarium")]
[assembly : AssemblyCopyright("")]
[assembly : AssemblyTrademark("")]
[assembly : AssemblyCulture("")]

[assembly : AssemblyDelaySign(false)]
[assembly : AssemblyKeyName("")]

[assembly: AssemblyVersion("2.1.0.*")]
[assembly: AssemblyFileVersion("2.1.0.0")]
