//------------------------------------------------------------------------------
//      Copyright (c) Microsoft Corporation.  All rights reserved.                                                             
//------------------------------------------------------------------------------

using System.Reflection;
using System.Runtime.CompilerServices;
using System;
using System.Runtime.InteropServices;
using System.Security;

[assembly: AllowPartiallyTrustedCallers()]
[assembly: ComVisible(false)]
[assembly: CLSCompliant(true)]

[assembly: AssemblyTitle("Terrarium.OrganismBase")]
[assembly: AssemblyDescription("")]
