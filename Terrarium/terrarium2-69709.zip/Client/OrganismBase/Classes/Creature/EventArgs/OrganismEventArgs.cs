//------------------------------------------------------------------------------
//      Copyright (c) Microsoft Corporation.  All rights reserved.                                                             
//------------------------------------------------------------------------------

using System;

namespace OrganismBase 
{
    /// <internal />
    [Serializable]
    public class OrganismEventArgs : EventArgs
    {
    }
}