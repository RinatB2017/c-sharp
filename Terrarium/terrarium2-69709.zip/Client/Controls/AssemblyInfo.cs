//------------------------------------------------------------------------------
//      Copyright (c) Microsoft Corporation.  All rights reserved.                                                              
//------------------------------------------------------------------------------

using System.Reflection;
using System;
using System.Runtime.InteropServices;

[assembly: CLSCompliant(false)]
[assembly: ComVisible(false)]

[assembly: AssemblyTitle("Terrarium.Controls")]
[assembly: AssemblyDescription("")]
