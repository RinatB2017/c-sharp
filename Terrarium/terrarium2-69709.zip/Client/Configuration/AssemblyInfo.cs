//------------------------------------------------------------------------------
//      Copyright (c) Microsoft Corporation.  All rights reserved.                                                        
//------------------------------------------------------------------------------

using System;
using System.Reflection;
using System.Runtime.InteropServices;

[assembly : CLSCompliant(true)]
[assembly : ComVisible(false)]
[assembly : AssemblyTitle("Terrarium.Configuration")]
[assembly : AssemblyDescription("Terrarium Configuration Client Module")]